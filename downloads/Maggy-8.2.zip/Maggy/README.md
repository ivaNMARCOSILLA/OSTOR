# Maggy 8.3.0 · electronicama.com

Aplicación web/PWA musical con cuentas y acceso de pago: **1 € por 14 días de bienvenida**, una vez por cuenta, y **6 € por un mes**. El catálogo se puede explorar públicamente; escuchar y usar las funciones personales requiere pago. PayPal.me procesa pagos manuales; el administrador los confirma desde su panel antes de activar el acceso.

- [Instalar, crear administrador y gestionar pagos](docs/ADMINISTRACION.md)
- [Funciones y limitaciones](docs/MAGGY.md)
- [Autoría e integridad editorial](AUTORIA_MAGGY.md)

El ZIP no contiene contraseñas, sesiones, usuarios ni bases de datos. En cada instalación crea tu administrador con `python manage.py create-admin --username admin`; la contraseña se pide sin mostrarla.

Esta versión requiere almacenamiento persistente para cuentas y pagos y HTTPS en producción. No desplegar como web estática o con SQLite efímero en Vercel. Dockerfile y compose.yaml son opciones de despliegue preparadas, todavía no probadas en Docker en este entorno. Los archivos en docs/archive describen versiones anteriores y no son instrucciones actuales.

El dominio electronicama.com no ha sido conectado ni desplegado desde esta tarea. Las fuentes musicales activas son Internet Archive y Audius; no requieren claves en esta edición. Los documentos legales siguen siendo provisionales.
