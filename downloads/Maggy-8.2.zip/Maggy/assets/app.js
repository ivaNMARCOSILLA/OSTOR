/**
 * MAGGY PRO 8.3.0 · Frontend modular sin compilación ni dependencias.
 * Edición y mantenimiento: Iván Marcos Illa · 2026-10-24.
 * © 2026 Iván Marcos Illa sobre las aportaciones originales de esta edición.
 * Audius, Internet Archive y sus contenidos pertenecen a sus titulares.
 */
'use strict';
await window.MaggySession.ready;
const storageKey = name => window.MaggySession ? window.MaggySession.key(name) : name;

const VERSION = '8.3.0';
const KEY = Object.freeze({ favorites: storageKey('electronicama_v7_favorites'), history: storageKey('electronicama_v7_history'), ads: storageKey('electronicama_ads_consent_v1') });
const MAX_FAVORITES = 160;
const MAX_HISTORY = 75;
const SOURCE_NAMES = { AUDIUS: 'AUDIUS', ARCHIVE: 'ARCHIVE' };
const byId = id => document.getElementById(id);

const supportedTrack = track => ['ARCHIVE', 'AUDIUS'].includes(track?.source);

const state = {
  view: 'discover', source: 'ALL', query: 'electronic music', page: 1,
  results: [], favorites: readList(KEY.favorites), history: readList(KEY.history),
  loading: false, request: null, currentTrack: null, queue: [], currentIndex: -1,
  audio: null, playSerial: 0
};

function readList(key) {
  try {
    const list = JSON.parse(localStorage.getItem(key) || '[]');
    if (!Array.isArray(list)) return [];
    return list.filter(x => x && typeof x === 'object' && typeof x.id === 'string' && typeof x.title === 'string' && supportedTrack(x)).slice(0, 160);
  } catch { return []; }
}
function writeList(key, list) { try { localStorage.setItem(key, JSON.stringify(list)); } catch { message('El almacenamiento local no está disponible.'); } }
function safeImage(src) { try { const url = new URL(src); return url.protocol === 'https:' ? url.href : ''; } catch { return ''; } }
function filteredTracks() {
  const base = state.view === 'favorites' ? state.favorites : state.view === 'history' ? state.history : state.results;
  const available = base.filter(supportedTrack);
  return state.source === 'ALL' ? available : available.filter(track => track.source === state.source);
}
function isFavorite(id) { return state.favorites.some(track => track.id === id); }
function message(text) { byId('result-status').textContent = text; }
function setStatus(text) { byId('player-message').textContent = text || ''; }
function emptyNode(tag, className, text) { const node = document.createElement(tag); if (className) node.className = className; if (text !== undefined) node.textContent = String(text); return node; }
function compactTrack(track) {
  const result = {};
  for (const key of ['id', 'title', 'channel', 'description', 'source', 'thumbnail', 'url', 'stream_url']) {
    if (typeof track[key] === 'string') result[key] = track[key].slice(0, 1200);
  }
  return result;
}
function rememberTrack(track) {
  state.history = [compactTrack(track), ...state.history.filter(x => x.id !== track.id)].slice(0, MAX_HISTORY);
  writeList(KEY.history, state.history);
}
function toggleFavorite(track) {
  if (window.MaggySession && !window.MaggySession.requireAccess()) return;
  state.favorites = isFavorite(track.id)
    ? state.favorites.filter(x => x.id !== track.id)
    : [compactTrack(track), ...state.favorites].slice(0, MAX_FAVORITES);
  writeList(KEY.favorites, state.favorites);
  byId('favorites-count').textContent = String(state.favorites.filter(supportedTrack).length);
  if (state.currentTrack) {
    const button = byId('player-favorite');
    button.textContent = isFavorite(state.currentTrack.id) ? '♥' : '♡';
    button.classList.toggle('saved', isFavorite(state.currentTrack.id));
    button.setAttribute('aria-label', isFavorite(state.currentTrack.id) ? 'Quitar de favoritos' : 'Guardar en favoritos');
  }
  render();
}
function cover(src, alt, fallback = '♫') {
  if (!safeImage(src)) return emptyNode('span', 'cover-fallback', fallback);
  const img = document.createElement('img');
  img.src = safeImage(src); img.alt = alt; img.loading = 'lazy'; img.decoding = 'async';
  img.referrerPolicy = 'no-referrer';
  img.addEventListener('error', () => img.replaceWith(emptyNode('span', 'cover-fallback', '♫')));
  return img;
}
function trackCard(track, list) {
  const card = emptyNode('article', 'track-card');
  const main = emptyNode('button', 'cover-button'); main.type = 'button';
  main.setAttribute('aria-label', `${window.MaggySession?.active === false ? 'Desbloquear' : 'Reproducir'} ${track.title} de ${track.channel || 'artista desconocido'}`);
  main.append(cover(track.thumbnail, `Portada de ${track.title}`), emptyNode('span', 'play-overlay', window.MaggySession?.active === false ? '🔒' : '▶'));
  main.addEventListener('click', () => playTrack(track, list));
  const details = emptyNode('div', 'track-body');
  const top = emptyNode('div', 'track-top');
  top.append(emptyNode('span', 'source-tag', SOURCE_NAMES[track.source] || 'MÚSICA'));
  const fav = emptyNode('button', `save-button${isFavorite(track.id) ? ' saved' : ''}`, window.MaggySession?.active === false ? '🔒' : isFavorite(track.id) ? '♥' : '♡');
  fav.type = 'button'; fav.title = 'Guardar / quitar de favoritos';
  fav.setAttribute('aria-label', isFavorite(track.id) ? `Quitar ${track.title} de favoritos` : `Guardar ${track.title} en favoritos`);
  fav.addEventListener('click', () => toggleFavorite(track));
  top.append(fav);
  if (safeImage(track.url)) { const link = emptyNode('a', 'track-origin', 'Fuente ↗'); link.href = safeImage(track.url); link.target = '_blank'; link.rel = 'noopener noreferrer'; details.append(link); }
  const title = emptyNode('button', 'track-title', track.title);
  title.type = 'button'; title.title = track.title;
  title.addEventListener('click', () => playTrack(track, list));
  const artist = emptyNode('p', 'track-artist', track.channel || 'Artista desconocido');
  details.append(top, title, artist); card.append(main, details);
  return card;
}
function render() {
  if (window.MaggySession?.active === false && state.view !== 'discover') state.view = 'discover';
  const list = filteredTracks();
  const grid = byId('track-grid');
  grid.replaceChildren();
  const titles = {
    discover: ['EXPLORA EL ', 'SONIDO', 'Explora los sonidos que marcan tu ritmo.'],
    favorites: ['TUS ', 'FAVORITOS', 'Guardados únicamente en este navegador.'],
    history: ['TU ', 'HISTORIAL', 'Tu música escuchada recientemente.']
  };
  const [first, emph, subtitle] = titles[state.view];
  const heading = byId('section-title');
  heading.replaceChildren(document.createTextNode(first), emptyNode('em', '', emph));
  byId('section-subtitle').textContent = subtitle;
  byId('results-meta').textContent = `${list.length} ${list.length === 1 ? 'PISTA' : 'PISTAS'}`;
  byId('clear-history').classList.toggle('hidden', state.view !== 'history' || state.history.length === 0);
  byId('quick-searches').classList.toggle('hidden', state.view !== 'discover');
  byId('hero').classList.toggle('hidden', state.view !== 'discover');
  document.querySelectorAll('[data-view]').forEach(button => {
    button.classList.toggle('active', button.dataset.view === state.view);
  });
  document.querySelectorAll('[data-source]').forEach(button => {
    button.classList.toggle('active', button.dataset.source === state.source);
    button.setAttribute('aria-pressed', String(button.dataset.source === state.source));
  });
  if (!list.length && !state.loading) {
    const empty = emptyNode('div', 'empty-state');
    const title = state.view === 'favorites' ? 'TODAVÍA NO HAY FAVORITOS' : state.view === 'history' ? 'TODAVÍA NO HAY HISTORIAL' : 'SIN RESULTADOS';
    empty.append(emptyNode('strong', '', title), emptyNode('p', '', state.view === 'discover' ? 'Prueba con otro artista, canción o estilo.' : 'Elige una canción y vuelve aquí.'));
    grid.append(empty);
  } else {
    const frag = document.createDocumentFragment();
    for (const track of list) frag.append(trackCard(track, list));
    grid.append(frag);
  }
  byId('load-more').classList.toggle('hidden', state.view !== 'discover' || state.source === 'AUDIUS' || state.results.length === 0 || state.page >= 10);
}
function goView(view) {
  if (!['discover', 'favorites', 'history'].includes(view)) return;
  if (view !== 'discover' && window.MaggySession && !window.MaggySession.requireAccess()) return;
  state.view = view;
  byId('mobile-nav').classList.add('hidden');
  byId('mobile-menu').setAttribute('aria-expanded', 'false');
  message(view === 'favorites' ? 'Tus canciones guardadas en este dispositivo.' : view === 'history' ? 'Las últimas canciones que has escuchado.' : `Explorando: ${state.query}`);
  render();
  byId('library').scrollIntoView({ behavior: 'smooth', block: 'start' });
}
async function requestSearch(query, append = false) {
  query = String(query || '').trim().replace(/\s+/g, ' ').slice(0, 90);
  if (!query) { message('Escribe un artista o una canción.'); return; }
  if (state.request) state.request.abort();
  const controller = new AbortController(); state.request = controller;
  state.view = 'discover';
  if (!append) { state.query = query; state.page = 1; state.results = []; state.source = 'ALL'; }
  state.loading = true;
  byId('search-button').disabled = true;
  byId('load-more').disabled = true;
  byId('search-input').value = query;
  message(`Buscando «${query}» en las plataformas musicales...`);
  render();
  try {
    const response = await fetch(`/api/search?q=${encodeURIComponent(query)}&page=${state.page}`, {
      signal: controller.signal, headers: { Accept: 'application/json' }
    });
    if (!response.ok) {
      if (response.status === 429) throw new Error('Límite temporal de búsquedas. Inténtalo de nuevo en un minuto.');
      throw new Error(`No se pudo completar la búsqueda (${response.status}).`);
    }
    const raw = await response.json();
    const data = Array.isArray(raw) ? raw.filter(supportedTrack) : raw;
    if (controller.signal.aborted) return;
    if (!Array.isArray(data)) throw new Error('La respuesta del servidor no es válida.');
    if (append) {
      const seen = new Set(state.results.map(item => item.id));
      state.results.push(...data.filter(item => item?.id && !seen.has(item.id)));
    } else state.results = data.filter(item => item && typeof item.id === 'string' && typeof item.title === 'string');
    message(`${state.results.length} resultados para «${query}»${append && data.length === 0 ? '. No quedan más resultados.' : ''}`);
    if (append && data.length === 0) state.page = 10;
  } catch (error) {
    if (error.name === 'AbortError') return;
    message(error.message || 'No se pudo conectar con el buscador.');
  } finally {
    if (state.request === controller) {
      state.loading = false; state.request = null;
      byId('search-button').disabled = false;
      byId('load-more').disabled = false;
      render();
    }
  }
}

function destroyMedia() {
  if (state.audio) { state.audio.pause(); state.audio.removeAttribute('src'); state.audio.load(); state.audio = null; }
  byId('player-media').replaceChildren();
  if ('mediaSession' in navigator) {
    try { navigator.mediaSession.playbackState = 'none'; navigator.mediaSession.metadata = null; } catch { /* no compatible */ }
  }
}
async function playTrack(track, queue = filteredTracks()) {
  if (!track || !track.id) return;
  if (!supportedTrack(track)) { message('Esta fuente ya no está disponible.'); return; }
  state.playSerial += 1;
  const serial = state.playSerial;
  if (window.MaggySession && !await window.MaggySession.verifyAccess()) return;
  if (serial !== state.playSerial) return;
  destroyMedia();
  state.currentTrack = track;
  state.queue = queue.filter(supportedTrack);
  state.currentIndex = Math.max(0, state.queue.findIndex(x => x.id === track.id));
  rememberTrack(track);
  byId('player').classList.remove('hidden');
  byId('player-title').textContent = track.title;
  byId('player-artist').textContent = `${track.channel || 'Artista'} · ${track.source}`;
  byId('player-art').replaceChildren(cover(track.thumbnail, `Portada de ${track.title}`));
  byId('previous-track').disabled = state.currentIndex <= 0;
  byId('next-track').disabled = state.currentIndex >= state.queue.length - 1;
  byId('player-favorite').textContent = isFavorite(track.id) ? '♥' : '♡';
  byId('player-favorite').classList.toggle('saved', isFavorite(track.id));
  byId('toggle-play').textContent = '▶';
  byId('toggle-play').setAttribute('aria-label', 'Reproducir');
  setStatus('Preparando el audio…');
  try {
    const response = await (window.MaggySession?.fetch || fetch)(`/api/resolve/${encodeURIComponent(track.id)}`);
    if (!response.ok) throw new Error('Audio no disponible');
    const data = await response.json();
    if (state.playSerial === serial && safeImage(data.stream_url)) startAudio(data.stream_url);
  } catch { if (state.playSerial === serial) setStatus('No se pudo preparar el audio. Comprueba tu acceso o prueba otra pista.'); }
  render();
}
function startAudio(url) {
  if (!safeImage(url)) { setStatus('Enlace de audio no válido.'); return; }
  const audio = document.createElement('audio');
  audio.controls = true; audio.autoplay = true; audio.preload = 'metadata'; audio.src = url;
  audio.addEventListener('ended', () => playNext());
  audio.addEventListener('play', () => {
    byId('toggle-play').textContent = 'Ⅱ'; byId('toggle-play').setAttribute('aria-label', 'Pausar');
    setStatus('Reproduciendo'); mediaSessionPlayback('playing');
  });
  audio.addEventListener('pause', () => {
    byId('toggle-play').textContent = '▶'; byId('toggle-play').setAttribute('aria-label', 'Reproducir');
    mediaSessionPlayback('paused');
  });
  audio.addEventListener('error', () => setStatus('El servidor de audio no está disponible. Prueba otra pista.'));
  state.audio = audio;
  setupAudioMediaSession(state.currentTrack);
  byId('player-media').replaceChildren(audio);
  audio.play().catch(() => setStatus('Pulsa ▶ para comenzar la reproducción.'));
}
/** Controles nativos del teléfono SOLO para streaming de Audius/Archive. */
function mediaSessionPlayback(value) {
  if (!('mediaSession' in navigator)) return;
  try { navigator.mediaSession.playbackState = value; } catch { /* no compatible */ }
}
function setupAudioMediaSession(track) {
  if (!track || !('mediaSession' in navigator)) return;
  try {
    const artwork = safeImage(track.thumbnail) ? [{src: safeImage(track.thumbnail), sizes: '512x512', type: 'image/jpeg'}] : [];
    if ('MediaMetadata' in window) navigator.mediaSession.metadata = new MediaMetadata({
      title: track.title, artist: track.channel || 'Artista', album: 'MAGGY', artwork
    });
    for (const [name, fn] of [
      ['play', () => state.audio?.play()], ['pause', () => state.audio?.pause()],
      ['nexttrack', playNext], ['previoustrack', playPrevious]
    ]) {
      try { navigator.mediaSession.setActionHandler(name, fn); } catch { /* no compatible */ }
    }
  } catch { /* media session opcional */ }
}
function playNext() { if (state.currentIndex < state.queue.length - 1) playTrack(state.queue[state.currentIndex + 1], state.queue); else setStatus('Fin de la lista.'); }
function playPrevious() { if (state.currentIndex > 0) playTrack(state.queue[state.currentIndex - 1], state.queue); }
function togglePlay() {
  if (state.audio) {
    if (state.audio.paused) state.audio.play().catch(() => setStatus('No se pudo iniciar el audio.'));
    else state.audio.pause();
  }
}

function closePlayer() {
  state.playSerial += 1;
  destroyMedia(); state.currentTrack = null; state.queue = []; state.currentIndex = -1;
  byId('player').classList.add('hidden'); setStatus('');
}

function advertisingConsent(value) {
  let previous = null;
  try {
    previous = localStorage.getItem(KEY.ads);
    localStorage.setItem(KEY.ads, value ? 'accepted' : 'rejected');
  } catch { /* Si el navegador bloquea storage, prevalece denegación */ }

  window.dataLayer = window.dataLayer || [];
  window.gtag = window.gtag || function () { window.dataLayer.push(arguments); };
  window.gtag('consent', 'update', {
    ad_storage: value ? 'granted' : 'denied',
    ad_user_data: value ? 'granted' : 'denied',
    ad_personalization: value ? 'granted' : 'denied',
    analytics_storage: 'denied'
  });

  if (value && !document.getElementById('electronicama-ads-script')) {
    const script = document.createElement('script');
    script.id = 'electronicama-ads-script';
    script.async = true;
    script.src = 'https://www.googletagmanager.com/gtag/js?id=AW-18507562663';
    document.head.append(script);
    window.gtag('js', new Date());
    window.gtag('config', 'AW-18507562663');
  }
  byId('consent-dialog').classList.add('hidden');
  // Un script de terceros ya cargado no puede desinstalarse limpiamente:
  // al revocar consentimiento recargamos con el estado denegado almacenado.
  if (!value && previous === 'accepted') window.location.reload();
}
function consentInit() {
  window.dataLayer = window.dataLayer || [];
  window.gtag = window.gtag || function () { window.dataLayer.push(arguments); };
  window.gtag('consent', 'default', {
    ad_storage: 'denied', ad_user_data: 'denied',
    ad_personalization: 'denied', analytics_storage: 'denied', wait_for_update: 500
  });
  let stored = null;
  try { stored = localStorage.getItem(KEY.ads); } catch { /* Denegado por defecto */ }
  if (stored === 'accepted') advertisingConsent(true);
  else if (stored !== 'rejected') byId('consent-dialog').classList.remove('hidden');
}
function init() {
  byId('favorites-count').textContent = String(state.favorites.filter(supportedTrack).length);
  document.querySelectorAll('[data-view]').forEach(button => button.addEventListener('click', () => goView(button.dataset.view)));
  document.querySelectorAll('[data-source]').forEach(button => button.addEventListener('click', () => { state.source = button.dataset.source; render(); }));
  document.querySelectorAll('[data-query]').forEach(button => button.addEventListener('click', () => {
    byId('library').scrollIntoView({ behavior: 'smooth' });
    requestSearch(button.dataset.query);
  }));
  byId('mobile-menu').addEventListener('click', () => {
    const hidden = byId('mobile-nav').classList.toggle('hidden');
    byId('mobile-menu').setAttribute('aria-expanded', String(!hidden));
  });
  byId('search-form').addEventListener('submit', event => { event.preventDefault(); requestSearch(byId('search-input').value); });
  byId('load-more').addEventListener('click', () => { if (!state.loading) { state.page += 1; requestSearch(state.query, true); } });
  byId('clear-history').addEventListener('click', () => {
    if (!window.confirm('¿Borrar el historial guardado en este navegador?')) return;
    state.history = []; writeList(KEY.history, []); render(); message('Historial borrado.');
  });
  byId('previous-track').addEventListener('click', playPrevious);
  byId('next-track').addEventListener('click', playNext);
  byId('toggle-play').addEventListener('click', togglePlay);
  byId('player-close').addEventListener('click', closePlayer);
  byId('player-favorite').addEventListener('click', () => { if (state.currentTrack) toggleFavorite(state.currentTrack); });
  byId('privacy-button').addEventListener('click', () => byId('consent-dialog').classList.remove('hidden'));
  byId('cookie-settings').addEventListener('click', () => byId('consent-dialog').classList.remove('hidden'));
  byId('consent-decline').addEventListener('click', () => advertisingConsent(false));
  byId('consent-accept').addEventListener('click', () => advertisingConsent(true));
  document.addEventListener('keydown', e => { if (e.key !== 'Escape') return; if (!byId('consent-dialog').classList.contains('hidden')) advertisingConsent(false); else closePlayer(); });
  consentInit();
  if ('serviceWorker' in navigator && location.protocol === 'https:') {
    window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));
  }
  window.addEventListener('maggy:access-changed', event => { if (!event.detail.active) closePlayer(); render(); });
  render();
  requestSearch(state.query);
  console.info(`MAGGY PRO ${VERSION} · Edición Iván Marcos Illa`);
}
window.addEventListener('maggy:play', event => { const list = Array.isArray(event.detail) ? event.detail : [event.detail]; if (list[0]?.id && list[0]?.source) playTrack(list[0], list); });
init();
